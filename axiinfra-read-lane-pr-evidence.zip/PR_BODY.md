`AxiWideToNarrowRead` 在窄 INCR、FIXED 和部分 WRAP 读事务中，会把下游返回数据写入错误的上游 lane。事务可以正常握手并返回 `OKAY`，但上游在有效字节位置读到旧数据、零或未知值。本修改让每个响应 entry 跟踪实际下游读地址，按 `ARSIZE`、`ARBURST` 更新地址，再译码出写入 lane。

## 问题表现

以下两组波形来自同一验证环境下的修复前后真实 VCD，均使用 `buffer=2`、seed 1。测试先完成数据写入及 B 响应，再发起读，因此读写竞争不是触发条件。图中的上游、下游分别指**读转换器**的 `io_uR`、`io_dR` 接口；时间为 ns。

测试数据：

```text
A = 0x0123456789abcdef
B = 0xfedcba9876543210
```

这里的 lane 指一个完整的下游物理数据字：512→64 有 8 个 64-bit lane；512→256 有 2 个 256-bit lane。lane 宽度与 `2^ARSIZE` 表示的每拍有效字节数需要分别考虑。

### 1. 512→64：WRAP 回绕后写入错误 lane

固定输入如下，两拍均为 8 B，不需要把一个上游 beat 拆成多个下游 beat：

```text
转换配置：512-bit → 64-bit，buffer=2
ARADDR  = 0x61008
ARLEN   = 1          // 2 beats
ARSIZE  = 3          // 8 B per beat
ARBURST = 2          // WRAP
转换器接口 ID = 0x702
下游第 0 拍：RDATA=A，RRESP=OKAY，RLAST=0
下游第 1 拍：RDATA=B，RRESP=OKAY，RLAST=1
```

WRAP 窗口是 16 B，两拍地址为 `0x61008 → 0x61000`。对应的 lane 应为 `1 → 0`，one-hot 写掩码应为 `0x02 → 0x01`。旧逻辑每接收一拍固定轮转一次，得到 `1 → 2`，将 B 写入 `[191:128]`，而本拍有效数据应位于 `[63:0]`。

| 时间 | 转换器接口事件 | 修复前 | 修复后 |
|---:|---|---|---|
| 575 ns | `dAr.fire` | 接受上述 AR | AR 参数相同 |
| 595 ns | 第 0 次 `dR.fire`，数据 A | mask=`0x02`，写 lane 1 | mask=`0x02`，写 lane 1 |
| 605 ns | 第 1 次 `dR.fire`，数据 B | mask=`0x04`，错误写 lane 2 | mask=`0x01`，正确写 lane 0 |
| 615 ns | 第 1 次 `uR.fire`，`RLAST=1` | 有效 `[63:0]=X`；B 出现在 `[191:128]` | 有效 `[63:0]=B` |

此处 X 落在**本拍必须有效**的字节位置，属于读数据错误；未使用 lane 的 X 不在比较范围内。

<!-- 发布时将 assets/control-wrap-before-after.png 拖入 GitHub PR 编辑器，以生成的图片附件链接替换下一行相对路径。 -->
![512→64 WRAP：修复前后实际波形](assets/control-wrap-before-after.png)

### 2. 512→256：窄 INCR 提前切换到高 256-bit lane

```text
转换配置：512-bit → 256-bit，buffer=2
ARADDR  = 0x880000
ARLEN   = 1          // 2 beats
ARSIZE  = 3          // 8 B per beat，低于下游 32 B 总线宽度
ARBURST = 1          // INCR
转换器接口 ID = 0x702
下游第 0 拍：有效 A 位于 RDATA[63:0]，RRESP=OKAY，RLAST=0
下游第 1 拍：有效 B 位于 RDATA[127:64]，RRESP=OKAY，RLAST=1
```

两拍地址为 `0x880000 → 0x880008`，均位于 512-bit 字的低 32 B，因此两拍都应选择 256-bit lane 0。旧逻辑却从 lane 0 切到 lane 1，把第二拍整个下游 256-bit 字放到了上游高半部分，B 从正确的 `[127:64]` 移到了 `[383:320]`。

| 时间 | 转换器接口事件 | 修复前 | 修复后 |
|---:|---|---|---|
| 555 ns | `dAr.fire` | 接受上述 AR | AR 参数相同 |
| 575 ns | 第 0 次 `dR.fire` | mask=`01`，写 lane 0 | mask=`01`，写 lane 0 |
| 585 ns | 第 1 次 `dR.fire` | mask=`10`，错误写 lane 1 | mask=`01`，继续写 lane 0 |
| 595 ns | 第 1 次 `uR.fire`，`RLAST=1` | 有效 `[127:64]=0`；B 出现在 `[383:320]` | 有效 `[127:64]=B` |

本例每个下游 beat 对应一个独立的上游 R beat。第二拍重新写低 256 bit 是正确行为；它只要求该拍地址所对应的字节 8–15 有效，不要求保留前一拍字节 0–7 的值。

<!-- 发布时将 assets/tensor-narrow-incr-before-after.png 拖入 GitHub PR 编辑器，以生成的图片附件链接替换下一行相对路径。 -->
![512→256 窄 INCR：修复前后实际波形](assets/tensor-narrow-incr-before-after.png)

两组对照中，AR 参数、RID、RRESP、RLAST、下游 RDATA 和接口握手时间均一致；差异出现在内部写掩码及上游数据位置。图中的写掩码来自实际 `mem_MPORT_mask_*` 信号。某次握手使用的是该时钟上升沿之前的数值，上升沿之后的地址和 mask 更新为下一拍准备。R 通道不携带地址，文中的逐拍地址由 AR 参数推导；修复版图中的 `beatAddr` 则是实际寄存器波形。

## 故障定位与上游归属

问题在下游 [rvnpu/hardware/AxiInfra](https://git.rvnpu.cn/rvnpu/hardware/AxiInfra) 的 WZ 验证中发现，定位到上游已有的 `src/main/scala/xs/infra/axi/AxiWideToNarrowRead.scala`，因此修复目标是本仓库的 `main`。

截至 2026-09-28，核对的上游基线是 [`29333d7b843943c5df4309f37deb6904d24a2bd0`](https://github.com/OpenXiangShan-Nanhu/AxiInfra/commit/29333d7b843943c5df4309f37deb6904d24a2bd0)。用于复现的 WZ 基线为 `4d502ff99856c4114529d6dcf74ccbc221053d73`。WZ 版本仅比该上游文件多出以下两行 poison 适配；去除这两行并统一换行后，文件内容完全相同：

```scala
io.uR.bits.poison := 0.U
require(mstParams.poisonBits == 0)
```

因此，出错的 lane 状态、响应命中条件和数据写入路径在上游已存在，不依赖下游新增的互连功能。定位链路如下：

1. 两组用例的第一拍 lane 和上游有效数据均正确，排除初始 lane 译码错误。
2. 第二拍 `io.dR.fire` 时，下游数据、ID 和 `RLAST` 正确，且能命中响应 entry。
3. 错误首先出现在 `mrgMskVec` 生成的 `rwm`：它选择了与该拍地址不符的 lane。
4. `mem.write(rwa, rwd, rwm)` 将正确数据写到错误位置，随后 `io.uR` 从该 entry 读出错误布局。

对应上游代码：

- [lane mask 初始化与固定循环移位，L196–L204](https://github.com/OpenXiangShan-Nanhu/AxiInfra/blob/29333d7b843943c5df4309f37deb6904d24a2bd0/src/main/scala/xs/infra/axi/AxiWideToNarrowRead.scala#L196-L204)。
- [返回数据及写掩码进入 mem，L217–L222](https://github.com/OpenXiangShan-Nanhu/AxiInfra/blob/29333d7b843943c5df4309f37deb6904d24a2bd0/src/main/scala/xs/infra/axi/AxiWideToNarrowRead.scala#L217-L222)。

此前 [PR #4](https://github.com/OpenXiangShan-Nanhu/AxiInfra/pull/4) 修复的是无握手入队和同 ID 拆分阻塞。本问题发生在正常完成 R 握手时，是独立的返回数据位置错误；本修改保留已有的握手一致性和同 ID 排序逻辑。

## 原因

原实现按起始 AR 地址初始化 mask，随后每次命中 R 握手都将 mask 循环移动一格：

```scala
when(io.dAr.fire && freeSel.bits(i)) {
  mrgMskVec(i)(j) :=
    io.dAr.bits.addr(log2Ceil(mdw / 8) - 1, log2Ceil(sdw / 8)) === j.U
}.elsewhen(rHitVec(i)) {
  mrgMskVec(i)(j) := mrgMskVec(i)((j + seg - 1) % seg)
}
```

这隐含假设：每个下游 R beat 都使地址前进一个完整的下游总线字宽。实际地址推进由 **SIZE 和 BURST** 决定：

| 事务 | 正确行为 | 固定轮转为何出错 |
|---|---|---|
| 窄 INCR，`2^SIZE < sdw/8` | 地址按实际 beat 字节数前进，多拍可能落在同一物理 lane | 每拍过早切换 lane |
| 未拆分的 FIXED | 地址不变，lane 保持 | 每拍仍切换 lane |
| 未拆分的部分 WRAP | 地址在本事务的回绕窗口内更新 | 在整个上游字的 lane 环内轮转，不能表示更小的 WRAP 窗口 |

这里的 FIXED/WRAP 问题针对仍保留这些 burst 类型的下游请求。原始宽读若已被拆成下游全字宽 INCR child burst，其 lane 应跟随该 child 的实际地址推进。

## 修复

修改仅涉及 `AxiWideToNarrowRead.scala`：以每个响应 entry 的地址状态替代独立循环移位的 mask 状态。

### 1. 在每个响应 entry 中保存下游地址上下文

新增以下字段：

```scala
val beatAddr  = UInt(log2Ceil(mstParams.dataBits / 8).W)
val beatSize  = UInt(3.W)
val beatBurst = UInt(2.W)
val wrapMask  = UInt(log2Ceil(mstParams.dataBits / 8).W)
```

只需保存上游数据字内的地址低位。对 512-bit 上游而言，`beatAddr` 为 6 位，足以区分 64 B 内的位置，不需要保存完整地址。

在 `io.dAr.fire` 分配 entry 时，使用**实际发出的下游 child AR**初始化：

```scala
spiltCtrlVec(i).beatAddr :=
  (io.dAr.bits.addr >> io.dAr.bits.size) << io.dAr.bits.size
spiltCtrlVec(i).beatSize  := io.dAr.bits.size
spiltCtrlVec(i).beatBurst := io.dAr.bits.burst
spiltCtrlVec(i).wrapMask  :=
  AxiComputeFunction.getMask(io.dAr.bits.len, io.dAr.bits.size)
```

使用 child AR 可同时覆盖已拆分的宽读和保留原 SIZE/BURST 的窄读。初始化地址按 SIZE 对齐，用于正确计算非对齐 INCR 第一拍之后的地址；首拍有效字节仍遵循原始 AXI 地址语义。

### 2. 仅在本 entry 实际接收 R 时推进地址

```scala
when(rHitVec(i)) {
  val entry = spiltCtrlVec(i)
  val incremented = entry.beatAddr + (1.U << entry.beatSize)
  val wrapped =
    (entry.beatAddr & ~entry.wrapMask) | (incremented & entry.wrapMask)
  entry.beatAddr := Mux(
    AxiComputeFunction.isFix(entry.beatBurst), entry.beatAddr,
    Mux(AxiComputeFunction.isWrap(entry.beatBurst), wrapped, incremented)
  )
}
```

`rHitVec` 已包含有效 entry、ID/次序匹配及 `io.dR.fire` 条件，因此 `RVALID=1、RREADY=0` 时不会提前更新地址。每个 entry 独立维护进度，不同 ID 交错返回时不会共用一个地址计数器。

### 3. 从当前地址组合译码出 one-hot 写掩码

```scala
private val mrgMskVec = VecInit(spiltCtrlVec.map { entry =>
  UIntToOH(entry.beatAddr(log2Ceil(mdw / 8) - 1, maxSlvSize), seg).asBools
}.map(VecInit(_)))
```

512→64 使用 `beatAddr[5:3]` 选择 8 个 lane；512→256 使用 `beatAddr[5]` 选择两个 lane。`mem.write`、接口握手、RID/RRESP/RLAST 处理及宽读合并边界判断继续使用原有逻辑。

## 验证

动态验证于 2026-09-23 在 WZ 环境完成，基于上述同源读转换器；2026-09-28 编写本报告时重新检查了源文件归属、补丁适用性、VCD 和原始结果。下表中的动态结果不冒充 GitHub `main` 上新运行的原生测试。

| 检查 | 修复前 | 修复后 |
|---|---|---|
| 512→64 WRAP 两拍复现 | 4 条 UVM_ERROR，读数据/scoreboard 比较失败 | checker PASS，UVM_WARNING/ERROR/FATAL 均为 0 |
| 512→256 窄 INCR 两拍复现 | 3 条 UVM_ERROR，读数据/scoreboard 比较失败 | checker PASS，UVM_WARNING/ERROR/FATAL 均为 0 |
| 独立 512→64 读转换器测试 | 1,568 笔，6,968 次比较错误 | 1,568 笔，0 errors |
| 独立 512→256 读转换器测试 | 1,576 笔，2,084 次比较错误 | 1,576 笔，0 errors |
| WZ `full_current` 场景清单 | 本次仅对已知失败做负向复现 | 89 项均取得有效 PASS 证据 |

独立测试共 3,144 笔，覆盖 SIZE 0–6、上游字内对齐偏移、FIXED/INCR/WRAP、WRAP 长度 2/4/8/16、非对齐窄读起始地址、AR/R 背压及两个不同 ID 的交错响应；检查有效字节、RID、RRESP、RLAST 和背压期间的输出稳定性。

89 项场景中，84 项首轮通过，另外 5 项首次在仿真启动前遇到 SVT 环境初始化冲突，随后使用相同场景、seed、参数串行补跑通过。原始失败记录保留，未将其改写成 PASS。

波形证据重新核对结果：

- 四份 VCD 共提取 20 次 AR/R 握手，与独立的 posedge trace 全部一致。
- 20 份原始波形/日志文件与留存的 SHA-256 清单一致。
- 修复前后两组事务的握手时间、AR 参数、ID、LAST、RESP 和下游 RDATA 一致。
- 89 项最终结果均重新核对到有效的原 checker PASS 日志。
- 面向上述上游提交的单文件补丁已通过 `git apply --check`。

本次报告整理未重新运行上游 `AxiWideToNarrowSpec`，也未测量综合面积或时序。现有动态证据的配置范围是 512→64、512→256、`buffer=2` 及 WZ full wrapper。
