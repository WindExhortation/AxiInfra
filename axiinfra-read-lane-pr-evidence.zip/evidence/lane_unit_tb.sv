`timescale 1ns/1ps
module lane_checker #(parameter SW = 64)(output bit done, output int errors, output int cases);
  bit clock = 0;
  always #5 clock = ~clock;
  bit reset = 1;
  logic io_uAr_ready, io_uAr_valid = 0;
  logic [10:0] io_uAr_bits_id = 0;
  logic [39:0] io_uAr_bits_addr = 0;
  logic [7:0] io_uAr_bits_len = 0;
  logic [2:0] io_uAr_bits_size = 0;
  logic [1:0] io_uAr_bits_burst = 0;
  wire io_uAr_bits_lock = 0;
  wire [3:0] io_uAr_bits_cache = 0, io_uAr_bits_qos = 0, io_uAr_bits_region = 0;
  wire [2:0] io_uAr_bits_prot = 0;
  logic io_uR_ready = 0, io_uR_valid, io_uR_bits_last;
  logic [10:0] io_uR_bits_id;
  logic [511:0] io_uR_bits_data;
  logic [1:0] io_uR_bits_resp;
  logic io_dAr_ready = 0, io_dAr_valid;
  logic [10:0] io_dAr_bits_id;
  logic [39:0] io_dAr_bits_addr;
  logic [7:0] io_dAr_bits_len;
  logic [2:0] io_dAr_bits_size;
  logic [1:0] io_dAr_bits_burst;
  logic io_dAr_bits_lock;
  logic [3:0] io_dAr_bits_cache, io_dAr_bits_qos, io_dAr_bits_region;
  logic [2:0] io_dAr_bits_prot;
  logic io_dR_ready, io_dR_valid = 0, io_dR_bits_last = 0;
  logic [10:0] io_dR_bits_id = 0;
  logic [SW-1:0] io_dR_bits_data = 0;
  logic [1:0] io_dR_bits_resp = 0;
  generate
    if (SW == 64) AxiWidthReadCvt512To64 dut(.*);
    else AxiWidthReadCvt512To256 dut(.*);
  endgenerate

  typedef struct {
    longint unsigned addr;
    longint unsigned wrap_base;
    int bytes, beats, index, burst, id;
  } txn;
  txn children[$];
  txn expected[2048];
  bit active[2048];
  int selected, rr, cycles, completed;
  bit r_accepted, stalls, interleave;
  bit held;
  logic [525:0] held_payload;

  function automatic longint unsigned next_address(txn t);
    longint unsigned a;
    if (t.burst == 0) return t.addr;
    a = (t.addr / t.bytes + 1) * t.bytes;
    if (t.burst == 2 && a >= t.wrap_base + t.bytes * t.beats)
      a = t.wrap_base;
    return a;
  endfunction
  function automatic byte pattern(longint unsigned addr, int id);
    return byte'((addr * 37) ^ (addr >> 7) ^ (id * 11) ^ 8'hd3);
  endfunction
  task automatic fail(string detail);
    errors++;
    if (errors <= 12) $display("LANE_MISMATCH SW=%0d %s", SW, detail);
  endtask

  always @(posedge clock) begin : monitor
    txn t;
    int id, lo, hi;
    cycles++;
    r_accepted = 0;
    if (!reset) begin
      if (io_uAr_valid && io_uAr_ready) begin
        id = io_uAr_bits_id;
        if (active[id]) $fatal(1, "test issued overlapping IDs");
        t.addr = io_uAr_bits_addr;
        t.bytes = 1 << io_uAr_bits_size;
        t.beats = int'(io_uAr_bits_len) + 1;
        t.burst = io_uAr_bits_burst;
        t.id = id;
        t.index = 0;
        t.wrap_base = (t.addr / (t.bytes * t.beats)) * (t.bytes * t.beats);
        expected[id] = t;
        active[id] = 1;
      end
      if (io_dAr_valid && io_dAr_ready) begin
        t.addr = io_dAr_bits_addr;
        t.bytes = 1 << io_dAr_bits_size;
        t.beats = int'(io_dAr_bits_len) + 1;
        t.burst = io_dAr_bits_burst;
        t.id = io_dAr_bits_id;
        t.index = 0;
        t.wrap_base = (t.addr / (t.bytes * t.beats)) * (t.bytes * t.beats);
        children.push_back(t);
      end
      if (io_dR_valid && io_dR_ready) begin
        r_accepted = 1;
        t = children[selected];
        t.index++;
        t.addr = next_address(t);
        if (t.index == t.beats) children.delete(selected);
        else children[selected] = t;
        rr = selected + 1;
      end
      if (held && (!io_uR_valid ||
          {io_uR_bits_id, io_uR_bits_data, io_uR_bits_resp, io_uR_bits_last} !== held_payload))
        fail("R payload changed under backpressure");
      held = io_uR_valid && !io_uR_ready;
      held_payload = {io_uR_bits_id, io_uR_bits_data, io_uR_bits_resp, io_uR_bits_last};
      if (io_uR_valid && io_uR_ready) begin
        id = io_uR_bits_id;
        if (!active[id]) $fatal(1, "unexpected response ID %0d", id);
        t = expected[id];
        lo = t.addr % 64;
        hi = ((t.addr / t.bytes) * t.bytes + t.bytes - 1) % 64;
        for (int b = lo; b <= hi; b++)
          if (io_uR_bits_data[8*b +: 8] !== pattern((t.addr / 64) * 64 + b, id))
            fail($sformatf("id=%0d burst=%0d size_bytes=%0d addr=%h beat=%0d byte=%0d got=%h expected=%h",
              id, t.burst, t.bytes, t.addr, t.index, b,
              io_uR_bits_data[8*b +: 8], pattern((t.addr / 64) * 64 + b, id)));
        if (io_uR_bits_resp !== 0 || io_uR_bits_last !== (t.index == t.beats-1))
          fail("incorrect RRESP or RLAST");
        t.index++;
        t.addr = next_address(t);
        expected[id] = t;
        if (t.index == t.beats) begin active[id] = 0; completed++; end
      end
    end
  end

  always @(negedge clock) begin : slave_driver
    txn t;
    if (!reset) begin
      io_dAr_ready = !stalls || cycles % 5 != 0;
      io_uR_ready = !stalls || cycles % 7 >= 3;
      if (!io_dR_valid || r_accepted) begin
        io_dR_valid = 0;
        if (children.size() && (!stalls || cycles % 4 != 0)) begin
          selected = interleave ? rr % children.size() : 0;
          t = children[selected];
          io_dR_bits_id = t.id;
          io_dR_bits_last = t.index == t.beats - 1;
          for (int b = 0; b < SW/8; b++)
            io_dR_bits_data[8*b +: 8] = pattern((t.addr / (SW/8)) * (SW/8) + b, t.id);
          io_dR_valid = 1;
        end
      end
    end
  end

  task automatic issue(longint unsigned addr, int size, int burst, int beats, int id);
    @(negedge clock);
    io_uAr_bits_addr = addr;
    io_uAr_bits_size = size;
    io_uAr_bits_burst = burst;
    io_uAr_bits_len = beats - 1;
    io_uAr_bits_id = id;
    io_uAr_valid = 1;
    do @(posedge clock); while (!io_uAr_ready);
    @(negedge clock);
    io_uAr_valid = 0;
    cases++;
  endtask
  task automatic drain(int goal);
    int deadline;
    deadline = cycles + 3000;
    while (completed < goal && cycles < deadline) @(negedge clock);
    if (completed != goal) $fatal(1, "LANE_TIMEOUT SW=%0d completed=%0d goal=%0d", SW, completed, goal);
  endtask
  task automatic run_case(longint unsigned addr, int size, int burst, int beats);
    int goal;
    goal = completed + 1;
    issue(addr, size, burst, beats, 1);
    drain(goal);
  endtask

  initial begin
    done = 0;
    errors = 0;
    cases = 0;
    selected = 0;
    rr = 0;
    cycles = 0;
    completed = 0;
    repeat (4) @(negedge clock);
    reset = 0;
    // All legal sizes and every aligned offset in the 512-bit bus word.
    for (int bp = 0; bp < 2; bp++) begin
      stalls = bp;
      for (int size = 0; size <= 6; size++)
        for (int offset = 0; offset < 64; offset += (1 << size)) begin
          run_case('h1000 + offset, size, 0, 4);
          run_case('h2000 + offset, size, 1, 8);
          foreach_wrap: for (int beats = 2; beats <= 16; beats *= 2)
            run_case('h4000 + offset, size, 2, beats);
        end
      // Legal unaligned starts exercise the shortened first transfer.
      for (int size = 1; size <= $clog2(SW/8); size++) begin
        run_case('h603f, size, 1, 8);
        run_case('h603b, size, 0, 4);
      end
    end
    // Two outstanding IDs return interleaved narrow R beats under stalls.
    interleave = 1;
    for (int n = 0; n < 16; n++) begin
      issue('h8000 + 8*n, 3, 1, 8, 2);
      issue('h9008 + 8*n, 3, 2, 4, 3);
      drain(cases);
    end
    repeat (8) @(negedge clock);
    if (children.size() || io_uR_valid) fail("undrained response");
    $display("[LANE_UNIT_DONE] SW=%0d cases=%0d errors=%0d", SW, cases, errors);
    done = 1;
  end
endmodule

module lane_unit_tb;
  wire done64, done256;
  wire [31:0] errors64, errors256, cases64, cases256;
  lane_checker #(64) control_check(done64, errors64, cases64);
  lane_checker #(256) tensor_check(done256, errors256, cases256);
  initial begin
    wait(done64 && done256);
    if (errors64 || errors256) $fatal(1, "[LANE_UNIT_FAIL] errors=%0d", errors64+errors256);
    $display("[LANE_UNIT_PASS] cases=%0d", cases64+cases256);
    $finish;
  end
  initial begin #20000000; $fatal(1, "global timeout"); end
endmodule
