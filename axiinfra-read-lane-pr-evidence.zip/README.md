# AxiWideToNarrowRead lane-selection evidence

Target: https://github.com/OpenXiangShan-Nanhu/AxiInfra
Pinned upstream main: 29333d7b843943c5df4309f37deb6904d24a2bd0

Read PR_PREVIEW.html offline, or read PR_BODY.md with assets/ intact.
The two PNGs are unmodified renderings of actual before/after VCD data.
Upload the images to the GitHub PR editor to replace the local image references.

evidence/waves/ contains four VCDs, posedge traces and checker results.
evidence/handshakes.json contains 20 extracted handshakes.
evidence/verified-summary.json records source attribution and evidence checks.
evidence/upstream-vs-wz.diff contains only two downstream poison-adaptation lines.
evidence/regression-closure.json lists 89 accepted WZ scenarios and checker hashes.
evidence/lane_unit_tb.sv is the existing standalone testbench used with generated WZ RTL.
The archive does not include all required RTL or the commercial VCS/SVT environment.

Dynamic simulations were performed on 2026-09-23 in the downstream WZ environment.
The report and original evidence were rechecked on 2026-09-28.
No new upstream native test or PPA measurement is claimed.
The single-file patch passes git apply --check against the pinned upstream source.

SHA256SUMS covers all included source/evidence/report files except this README and itself.
